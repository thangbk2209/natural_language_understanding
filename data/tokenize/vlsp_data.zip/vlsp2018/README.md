## Corpus Summary

Corpus is in [UniversalDependencies format](https://github.com/UniversalDependencies/UD_Vietnamese).

```
Sentences     : 14861
Unique words  : 18123
Top words     : ,, ., ", của, là, một, và, có, được, người, không, đã, những, cho, ..., ở, :, trong, đến, “
POS Tags (36) : A, Ab, B-NP, C, CH, Cb, Cc, E, FW, Fw, I, I-NP, L, M, N, NNP, NNPY, NPP, Nb, Nc, Ne, Ni, Ns, Nu, Ny, O, P, Pp, R, T, V, Vb, Vy, X, Z, p
Chunking Tags (14) : B-AP, B-EP, B-IP, B-MP, B-NP, B-NPb, B-PP, B-VP, B-VPb, I-AP, I-NP, I-RP, I-VP, O
NER Tags (9) :B-LOC, B-MISC, B-ORG, B-PER, I-LOC, I-MISC, I-ORG, I-PER, O
```